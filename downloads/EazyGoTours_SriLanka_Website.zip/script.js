const modal = document.getElementById('bookingModal');
const closeModal = document.getElementById('closeModal');
const form = document.getElementById('bookingForm');
const success = document.getElementById('success');

function openBooking(packageName = '') {
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  if (packageName) {
    const select = form.querySelector('[name="interest"]');
    [...select.options].forEach(o => { if (o.text === packageName) select.value = packageName; });
  }
  setTimeout(() => form.querySelector('input')?.focus(), 100);
}
function hideBooking() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
}
document.querySelectorAll('[data-open-booking]').forEach(btn => btn.addEventListener('click', () => openBooking()));
document.querySelectorAll('[data-package]').forEach(btn => btn.addEventListener('click', () => openBooking(btn.dataset.package)));
closeModal.addEventListener('click', hideBooking);
modal.addEventListener('click', e => { if (e.target === modal) hideBooking(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') hideBooking(); });

form.addEventListener('submit', e => {
  e.preventDefault();
  success.classList.add('show');
  success.textContent = '✓ Thanks! Your enquiry is ready. Connect this form to your email/WhatsApp/CRM backend to receive the submission.';
  form.reset();
});

const menuBtn = document.getElementById('menuBtn');
const nav = document.getElementById('desktopNav');
menuBtn.addEventListener('click', () => {
  const open = nav.classList.toggle('mobile-open');
  if (open) {
    nav.style.display = 'flex';
    nav.style.position = 'absolute';
    nav.style.top = '72px';
    nav.style.left = '0';
    nav.style.right = '0';
    nav.style.padding = '18px 7%';
    nav.style.background = '#fff';
    nav.style.flexDirection = 'column';
    nav.style.gap = '16px';
    nav.style.boxShadow = '0 15px 30px rgba(0,0,0,.08)';
  } else nav.removeAttribute('style');
});
