# EazyGo Tours — Sri Lanka Tourism Website

This is a polished, responsive front-end website concept for EazyGo Tours.

## Included
- Responsive homepage
- EazyGo Tours supplied logo in `assets/eazygo-logo.png`
- Hero section
- Experience categories
- Tour package cards
- Destinations section
- Why EazyGo section
- Traveller testimonial
- Booking/enquiry modal
- Mobile navigation
- Smooth scrolling
- No build tools required

## Run
Open `index.html` in a modern browser.

## Important
The package prices, contact details, testimonials and form submission are demo content. Replace them with the real company information before publishing.

The photos are loaded from Unsplash URLs, so an internet connection is needed for the photography.
